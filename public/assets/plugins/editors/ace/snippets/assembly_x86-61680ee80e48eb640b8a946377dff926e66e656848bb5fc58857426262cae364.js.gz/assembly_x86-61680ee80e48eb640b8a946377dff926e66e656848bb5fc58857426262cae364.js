define("ace/snippets/assembly_x86",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="assembly_x86"})
