define("ace/snippets/luapage",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="luapage"})
