define("ace/snippets/protobuf",["require","exports","module"],function(e,t,n){"use strict";t.snippetText="",t.scope="protobuf"})
